
namespace Consumers;

public class SendEmailEvent
{
    public string Email { get; set; }
}

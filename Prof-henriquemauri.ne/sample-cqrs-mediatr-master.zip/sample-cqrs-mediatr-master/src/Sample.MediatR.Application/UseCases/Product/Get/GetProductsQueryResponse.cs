
namespace Sample.MediatR.Application.UseCases.Product.Get;
public class GetProductsQueryResponse
{
    public long Id { get; set; }
    public string Description { get; set; }
}

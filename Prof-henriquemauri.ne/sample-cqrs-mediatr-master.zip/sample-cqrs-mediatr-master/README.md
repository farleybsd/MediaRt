# sample-cqrs-mediatr
CQRS with MediatR in .NET 7.0

### 
- [x] .NET 7.0
- [x] MediatR 
- [x] Swagger 
- [x] Serilog 
- [x] Middlewares

https://henriquemauri.net/mediatr-no-net-6-0/
